

set -o errexit
set -o errtrace
set -o pipefail

LANGUAGE_TYPE_FROM_DESCRIPTOR="$( getLanguageType )"

if [[ "${LANGUAGE_TYPE}" != "" ]]; then
	echo "Language type [${LANGUAGE_TYPE}] passed from env variables"
elif [[ "${LANGUAGE_TYPE_FROM_DESCRIPTOR}" != "" ]]; then
	LANGUAGE_TYPE="${LANGUAGE_TYPE_FROM_DESCRIPTOR}"
else
	echo "Language needs to be guessed from the sources"
	LANGUAGE_TYPE="$( guessLanguageType )"
	if [[ "${LANGUAGE_TYPE}" == "" ]]; then
		echo "Failed to guess the language type!"
		return 1
	fi
fi

echo "Language type [${LANGUAGE_TYPE}]"
[[ -f "${__DIR}/projectType/pipeline-${LANGUAGE_TYPE}.sh" ]] && source "${__DIR}/projectType/pipeline-${LANGUAGE_TYPE}.sh" ||  \
 echo "No projectType/pipeline-${LANGUAGE_TYPE}.sh found"
